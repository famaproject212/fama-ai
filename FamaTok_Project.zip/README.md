# FamaTok — HTML/CSS/JavaScript

Project frontend aplikasi video pendek yang dapat langsung dibuka di browser.

## Menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser modern.
3. Untuk pengalaman terbaik di Android, gunakan Chrome.

## Fitur
- Feed video vertikal + scroll/snap
- Autoplay/pause video
- Like
- Komentar
- Follow
- Bookmark/simpan
- Share memakai Web Share API
- Pencarian
- Upload video dari perangkat
- Profil dan grid video
- Data interaksi tersimpan di localStorage
- Responsive untuk layar HP

## Catatan
Project ini adalah implementasi mandiri dengan branding FamaTok, bukan salinan resmi TikTok.
Video contoh memakai URL demo publik. Untuk aplikasi produksi, gunakan backend/CDN/storage sendiri.

## Menjadikan APK
Project ini dapat dibungkus menggunakan Capacitor, Cordova, atau WebView Android. Contoh alur Capacitor:
- `npm install`
- `npm install @capacitor/core @capacitor/cli @capacitor/android`
- `npx cap init FamaTok com.famatok.app`
- `npx cap add android`
- Salin isi project ke folder web yang digunakan Capacitor
- `npx cap sync`
- `npx cap open android`

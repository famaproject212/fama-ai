const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const videos=[
 {id:1,user:"@fama",name:"Fama",caption:"Selamat datang di FamaTok! Swipe untuk melihat video berikutnya.",song:"Original sound • FamaTok",src:"https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"},
 {id:2,user:"@creator",name:"Creator",caption:"Video pendek, komentar, like, follow, dan bookmark dalam satu aplikasi.",song:"Original sound • Creator",src:"https://www.w3schools.com/html/mov_bbb.mp4"},
 {id:3,user:"@nature",name:"Nature",caption:"Nikmati video vertikal favoritmu.",song:"Nature sounds",src:"https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4"}
];
let state=JSON.parse(localStorage.getItem("famatok_state")||"null")||{likes:{},saved:{},following:{},comments:{},posts:[]};
let currentCommentId=null;

function save(){localStorage.setItem("famatok_state",JSON.stringify(state))}
function allVideos(){return [...state.posts,...videos]}
function countComments(id){return (state.comments[id]||[]).length}
function renderFeed(list=allVideos()){
 const feed=$("#feed"); feed.innerHTML="";
 list.forEach(v=>{
  const liked=!!state.likes[v.id], saved=!!state.saved[v.id], followed=!!state.following[v.user];
  const card=document.createElement("article"); card.className="video-card"; card.dataset.id=v.id;
  card.innerHTML=`<video playsinline loop preload="metadata" src="${v.src}"></video>
   <div class="video-gradient"></div><div class="play-center">▶</div>
   <div class="video-info"><div class="user-row"><div class="avatar">${v.name[0].toUpperCase()}</div><span class="username">${v.user}</span><button class="follow-mini" data-action="follow">${followed?"Mengikuti":"Ikuti"}</button></div>
   <div class="caption">${escapeHtml(v.caption||"")}</div><div class="music">♫ ${escapeHtml(v.song||"Original sound")}</div></div>
   <div class="side-actions"><div class="avatar-side">${v.name[0].toUpperCase()}${!followed?'<i class="plus">+</i>':''}</div>
   <button class="action ${liked?"liked":""}" data-action="like"><span class="ico">♥</span><small>${liked?"Disukai":"Suka"}</small></button>
   <button class="action" data-action="comment"><span class="ico">●</span><small>${countComments(v.id)}</small></button>
   <button class="action ${saved?"saved":""}" data-action="save"><span class="ico">🔖</span><small>${saved?"Tersimpan":"Simpan"}</small></button>
   <button class="action" data-action="share"><span class="ico">↗</span><small>Bagikan</small></button></div>`;
  feed.appendChild(card);
 });
 attachVideoEvents();
 observeVideos();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function attachVideoEvents(){
 $$(".video-card video").forEach(v=>v.addEventListener("click",()=>{v.paused?v.play():v.pause();v.closest(".video-card").classList.toggle("paused",v.paused)}));
 $$(".video-card").forEach(card=>card.addEventListener("click",e=>{
   const btn=e.target.closest("[data-action]"); if(!btn)return;
   const id=Number(card.dataset.id), v=allVideos().find(x=>x.id===id), a=btn.dataset.action;
   if(a==="like"){state.likes[id]=!state.likes[id];save();renderFeed()}
   if(a==="save"){state.saved[id]=!state.saved[id];save();renderFeed()}
   if(a==="follow"){state.following[v.user]=!state.following[v.user];save();renderFeed()}
   if(a==="comment")openComments(id);
   if(a==="share")shareVideo(v);
 }));
}
function observeVideos(){
 const io=new IntersectionObserver(entries=>entries.forEach(en=>{
   const vid=en.target;
   if(en.isIntersecting){vid.play().catch(()=>{});vid.closest(".video-card").classList.remove("paused")}
   else vid.pause();
 }),{threshold:.7});
 $$(".video-card video").forEach(v=>io.observe(v));
}
async function shareVideo(v){
 const data={title:"FamaTok",text:`Lihat video ${v.user} di FamaTok!`};
 try{if(navigator.share)await navigator.share(data);else{await navigator.clipboard.writeText(location.href);toast("Link disalin")}}catch{}
}
function openComments(id){
 currentCommentId=id;$("#commentsSheet").classList.remove("hidden");renderComments();
}
function renderComments(){
 const list=$("#commentsList"), arr=state.comments[currentCommentId]||[];
 list.innerHTML=arr.length?arr.map(c=>`<div class="comment"><div class="avatar">${c.user[0]}</div><div><b>${c.user}</b><p>${escapeHtml(c.text)}</p><small>${c.time}</small></div></div>`).join(""):`<div style="text-align:center;color:#777;padding:40px 10px">Henya kamu yang bisa memulai komentar.</div>`;
}
$("#commentForm").addEventListener("submit",e=>{e.preventDefault();const input=$("#commentInput"),text=input.value.trim();if(!text)return;(state.comments[currentCommentId]??=[]).push({user:"kamu",text,time:"baru saja"});input.value="";save();renderComments();renderFeed()});
function close(id){$("#"+id).classList.add("hidden")}
$$("[data-close]").forEach(b=>b.addEventListener("click",()=>close(b.dataset.close)));
function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
$("#uploadBtn").onclick=()=>$("#uploadSheet").classList.remove("hidden");
$("#uploadForm").addEventListener("submit",e=>{
 e.preventDefault();const f=$("#videoFile").files[0];if(!f)return;
 const src=URL.createObjectURL(f),id=Date.now();state.posts.unshift({id,user:"@kamu",name:"Kamu",caption:$("#caption").value||"Video baru",song:$("#song").value||"Original sound",src});save();e.target.reset();close("uploadSheet");renderFeed();toast("Video berhasil diposting");
});
$("#searchBtn").onclick=()=>{openSearch();}; $("#searchInput").addEventListener("input",doSearch);
function openSearch(){close("profilePanel");$("#searchPanel").classList.remove("hidden");setTimeout(()=>$("#searchInput").focus(),100)}
function doSearch(){const q=$("#searchInput").value.toLowerCase().trim(),out=$("#searchResults");if(!q){out.innerHTML="<p style='color:#777;text-align:center;padding:30px'>Ketik sesuatu untuk mencari.</p>";return}const r=allVideos().filter(v=>(v.user+" "+v.name+" "+v.caption).toLowerCase().includes(q));out.innerHTML=r.length?r.map(v=>`<div class="result" data-id="${v.id}"><div class="avatar">${v.name[0]}</div><div class="result-text"><b>${v.user}</b><small>${escapeHtml(v.caption)}</small></div></div>`).join(""):"<p style='color:#777;text-align:center;padding:30px'>Tidak ditemukan.</p>";$$(".result").forEach(x=>x.onclick=()=>{close("searchPanel");const card=document.querySelector(`.video-card[data-id="${x.dataset.id}"]`);card?.scrollIntoView({behavior:"smooth"})})}
function openProfile(){close("searchPanel");$("#profilePanel").classList.remove("hidden");const posts=state.posts;$("#profileContent").innerHTML=`<div class="profile-box"><div class="profile-avatar">K</div><div class="profile-name">@kamu</div><div class="stats"><div><b>${posts.length}</b><small>Video</small></div><div><b>${Object.keys(state.following).length}</b><small>Mengikuti</small></div><div><b>${Object.values(state.likes).filter(Boolean).length}</b><small>Disukai</small></div></div><button class="profile-btn">Edit profil</button></div><div class="grid">${posts.map(v=>`<div class="grid-item"><video muted src="${v.src}"></video></div>`).join("")}</div>`}
$$(".nav-item").forEach(n=>n.onclick=()=>{const tab=n.dataset.tab;$$(".nav-item").forEach(x=>x.classList.remove("active"));n.classList.add("active");if(tab==="profile")openProfile();else if(tab==="discover")openSearch();else if(tab==="inbox"){toast("Belum ada notifikasi baru")}else{close("profilePanel");close("searchPanel");$("#feed").scrollTo({top:0,behavior:"smooth"})}});
$("#inboxBtn").onclick=()=>toast("Belum ada notifikasi baru");
renderFeed();
